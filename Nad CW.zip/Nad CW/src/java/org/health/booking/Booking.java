/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.health.booking;

/**
 *
 * @author user
 */
public class Booking {
//        CREATE TABLE `bookings` (
//  `bookingId` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
//  `vaccineName` varchar(255) NOT NULL,
//  `place` varchar(255) DEFAULT NULL,
//  `date` date  NULL,
//  `healthCenterName` int(11) NOT NULL
//) 
    
}
