/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.health.administration;

/**
 *
 * @author user
 */
public class VaccinationAdministrationModule {
//        CREATE TABLE `patients` (
//  `patientsId` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
//  `healthCenterName` varChar(255) NOT NULL,
//  `NIN` varchar(255) NOT NULL,
//  `dateOfVaccination` date  NULL,
//  `returnDate` date  NULL,
//  `typeOfVaccine` varchar(255) NOT NULL,
//  `batchNumber` varchar(255) NULL
//)
    
}
