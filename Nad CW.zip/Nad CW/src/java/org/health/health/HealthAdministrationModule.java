/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.health.health;

/**
 *
 * @author user
 */
public class HealthAdministrationModule {
    
//    CREATE TABLE `healthcentres` (
//  `healthCenterId` int(11) NOT NULL,
//  `healthCenterName` varchar(255) NOT NULL,
//  `totalPatients` int(11) NOT NULL,
//  `totalVaccines` int(11) NOT NULL,
//  `receiveDate` date  NULL,
//  `receiveMonth` varchar(255)  NULL,
//  `vaccineName` varchar(255)  NULL
//)
    
}
